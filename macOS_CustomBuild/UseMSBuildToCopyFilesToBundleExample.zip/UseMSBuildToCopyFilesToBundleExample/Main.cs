﻿using AppKit;

namespace UseMSBuildToCopyFilesToBundleExample
{
	static class MainClass
	{
		static void Main (string[] args)
		{
			NSApplication.Init ();
			NSApplication.Main (args);
		}
	}
}
